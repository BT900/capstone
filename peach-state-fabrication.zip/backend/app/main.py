from fastapi import FastAPI
app = FastAPI(title="Peach State Fabrication API")

@app.get("/")
def root():
    return {"status":"ok"}
