from datetime import datetime,timedelta
from jose import jwt
from passlib.context import CryptContext
import os
pwd=CryptContext(schemes=['bcrypt'])
SECRET=os.getenv('SECRET_KEY','change_me')
ALG='HS256'
def hash_password(p): return pwd.hash(p)
def verify_password(p,h): return pwd.verify(p,h)
def create_token(sub): return jwt.encode({'sub':sub,'exp':datetime.utcnow()+timedelta(days=1)},SECRET,algorithm=ALG)
