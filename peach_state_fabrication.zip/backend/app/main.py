from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .routers import users,quotes,projects,payments
app=FastAPI(title='Peach State Fabrication API')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_methods=['*'],allow_headers=['*'])
app.include_router(users.router)
app.include_router(quotes.router)
app.include_router(projects.router)
app.include_router(payments.router)
@app.get('/')
def root(): return {'status':'ok'}
