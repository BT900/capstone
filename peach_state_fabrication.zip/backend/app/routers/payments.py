from fastapi import APIRouter
router=APIRouter(prefix='/payments',tags=['payments'])
@router.post('/intent')
def create_intent(): return {'client_secret':'demo_secret'}
