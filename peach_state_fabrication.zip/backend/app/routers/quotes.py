from fastapi import APIRouter
router=APIRouter(prefix='/quotes',tags=['quotes'])
quotes=[]
@router.get('/')
def list_quotes(): return quotes
@router.post('/')
def create_quote(payload:dict): quotes.append(payload); return {'success':True}
