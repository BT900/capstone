from fastapi import APIRouter
router=APIRouter(prefix='/projects',tags=['projects'])
projects=[]
@router.get('/')
def list_projects(): return projects
@router.post('/')
def add_project(payload:dict): projects.append(payload); return {'success':True}
