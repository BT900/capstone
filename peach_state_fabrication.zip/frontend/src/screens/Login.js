import React,{useState} from 'react';
import {View,TextInput,Button} from 'react-native';
import api from '../services/api';
export default function Login(){const[email,setEmail]=useState('');const[password,setPassword]=useState('');
return <View><TextInput placeholder='Email' onChangeText={setEmail}/><TextInput placeholder='Password' secureTextEntry onChangeText={setPassword}/><Button title='Login' onPress={async()=>await api.post('/auth/login',{email,password})}/></View>}
