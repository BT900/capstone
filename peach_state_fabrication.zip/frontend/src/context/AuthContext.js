import React,{createContext,useState,useContext} from 'react';
const AuthContext=createContext();
export const useAuth=()=>useContext(AuthContext);
export default function AuthProvider({children}){
 const [user,setUser]=useState(null);
 const login=(data)=>setUser(data);
 const logout=()=>setUser(null);
 return <AuthContext.Provider value={{user,login,logout}}>{children}</AuthContext.Provider>
}
