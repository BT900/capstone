import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import Home from '../screens/Home';
import Services from '../screens/Services';
import Projects from '../screens/Projects';
import Quote from '../screens/Quote';
const Tab=createBottomTabNavigator();
export default function Tabs(){return <Tab.Navigator><Tab.Screen name='Home' component={Home}/><Tab.Screen name='Services' component={Services}/><Tab.Screen name='Projects' component={Projects}/><Tab.Screen name='Quote' component={Quote}/></Tab.Navigator>}
